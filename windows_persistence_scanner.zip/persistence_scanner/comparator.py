"""Compare baseline and current persistence items.

This module provides functionality to identify new, removed and modified
persistence items between two scans.  Items are keyed by their `id` field.
If the same `id` exists in both baseline and current lists but other
attributes differ, the item is considered modified.  Items appearing only in
the current list are considered new, and those missing from the current list
relative to the baseline are considered removed.
"""

from __future__ import annotations

from typing import List, Dict, Any, Tuple


def diff_baseline(baseline: List[Dict[str, Any]], current: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Compute differences between baseline and current persistence lists.

    Args:
        baseline: List of items from the baseline scan.
        current: List of items from the current scan.

    Returns:
        A dictionary with keys `new`, `removed`, and `modified`, each
        containing a list of items.
    """
    baseline_map: Dict[str, Dict[str, Any]] = {item["id"]: item for item in baseline}
    current_map: Dict[str, Dict[str, Any]] = {item["id"]: item for item in current}

    new_items: List[Dict[str, Any]] = []
    removed_items: List[Dict[str, Any]] = []
    modified_items: List[Dict[str, Any]] = []

    # Identify new and modified items
    for cid, citem in current_map.items():
        if cid not in baseline_map:
            new_items.append(citem)
        else:
            bitem = baseline_map[cid]
            # If any property other than timestamp differs, treat as modified
            # Remove timestamp to compare relevant fields
            bcomp = {k: v for k, v in bitem.items() if k != "timestamp"}
            ccomp = {k: v for k, v in citem.items() if k != "timestamp"}
            if bcomp != ccomp:
                modified_items.append({"baseline": bitem, "current": citem})

    # Identify removed items
    for bid, bitem in baseline_map.items():
        if bid not in current_map:
            removed_items.append(bitem)

    return {
        "new": new_items,
        "removed": removed_items,
        "modified": modified_items,
    }