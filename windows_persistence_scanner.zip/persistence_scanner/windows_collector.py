"""Windows-specific persistence collectors.

This module contains functions to enumerate common Windows persistence
mechanisms such as startup folders, Run registry keys, services and
scheduled tasks.  These functions attempt to use native Python modules
(`winreg`) and command-line tools (`sc`, `schtasks`) to gather
information.  If any subprocess call fails, the function will skip
that category gracefully.

The primary function exported is `collect_windows_persistence()` which
returns a list of persistence items in a uniform format.  Each item
has at least the following keys:

* `id` – a unique identifier (usually derived from the name or path).
* `name` – the display name of the persistence entry.
* `location` – where the persistence entry is defined (file path,
  registry key, service name, scheduled task folder, etc.).
* `type` – a high-level type such as `startup_folder`, `registry_run`,
  `service` or `scheduled_task`.
* `hash` – a SHA256 of the executable or script if available, or empty
  string if not applicable.
* `timestamp` – ISO8601 UTC timestamp when collected.

Note: This code has been written without direct execution on a
Windows host.  There may be edge cases or parsing differences on
different Windows versions.  It is intended as a starting point for
development and likely requires adaptation for production use.
"""

from __future__ import annotations

import csv
import hashlib
import os
import subprocess
import sys
from datetime import datetime
from typing import List, Dict, Any, Optional

try:
    import winreg  # type: ignore
except ImportError:
    # winreg is only available on Windows; alias to None so type checking works
    winreg = None  # type: ignore


def _current_timestamp() -> str:
    return datetime.utcnow().isoformat() + "Z"


def _hash_file(path: str) -> str:
    """Compute SHA256 hash of a file.  Returns empty string on error."""
    try:
        with open(path, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()
    except Exception:
        return ""


def collect_windows_persistence() -> List[Dict[str, Any]]:
    """Collect persistence items from various Windows sources."""
    items: List[Dict[str, Any]] = []
    items += _collect_startup_folders()
    items += _collect_run_registry_keys()
    items += _collect_services()
    items += _collect_scheduled_tasks()
    return items


def _collect_startup_folders() -> List[Dict[str, Any]]:
    """Collect persistence items from startup folders for all users and the system."""
    entries: List[Dict[str, Any]] = []
    now = _current_timestamp()
    # Determine common startup directories
    paths = []
    try:
        appdata = os.environ.get("APPDATA")
        if appdata:
            paths.append(os.path.join(appdata, "Microsoft", "Windows", "Start Menu", "Programs", "Startup"))
        programdata = os.environ.get("PROGRAMDATA")
        if programdata:
            paths.append(os.path.join(programdata, "Microsoft", "Windows", "Start Menu", "Programs", "Startup"))
    except Exception:
        pass
    for path in paths:
        if not os.path.isdir(path):
            continue
        try:
            for name in os.listdir(path):
                full_path = os.path.join(path, name)
                if os.path.isfile(full_path):
                    entries.append({
                        "id": hashlib.md5(full_path.encode("utf-8")).hexdigest(),
                        "name": name,
                        "location": full_path,
                        "type": "startup_folder",
                        "hash": _hash_file(full_path),
                        "timestamp": now,
                    })
        except Exception:
            continue
    return entries


def _collect_run_registry_keys() -> List[Dict[str, Any]]:
    """Collect persistence items from common Run registry keys."""
    entries: List[Dict[str, Any]] = []
    now = _current_timestamp()
    if winreg is None:
        return entries
    # List of (root, subkey) pairs
    keys = [
        (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run"),
        (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\RunOnce"),
        (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\Run"),
        (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\RunOnce"),
    ]
    for root, subkey in keys:
        try:
            with winreg.OpenKey(root, subkey) as hkey:
                i = 0
                while True:
                    try:
                        name, value, _ = winreg.EnumValue(hkey, i)
                    except OSError:
                        break
                    # value may contain quotes and arguments; extract path heuristically
                    exe_path = value.strip('"').split(" ")[0]
                    entries.append({
                        "id": hashlib.md5(f"{subkey}:{name}".encode("utf-8")).hexdigest(),
                        "name": name,
                        "location": f"{root_name(root)}\\{subkey}",
                        "type": "registry_run",
                        "hash": _hash_file(exe_path) if os.path.isfile(exe_path) else "",
                        "timestamp": now,
                    })
                    i += 1
        except Exception:
            continue
    return entries


def root_name(root: int) -> str:
    """Return a string representation of a registry root constant."""
    mapping = {
        getattr(winreg, 'HKEY_CURRENT_USER', -1): 'HKEY_CURRENT_USER',
        getattr(winreg, 'HKEY_LOCAL_MACHINE', -1): 'HKEY_LOCAL_MACHINE',
        getattr(winreg, 'HKEY_CLASSES_ROOT', -1): 'HKEY_CLASSES_ROOT',
        getattr(winreg, 'HKEY_USERS', -1): 'HKEY_USERS',
        getattr(winreg, 'HKEY_CURRENT_CONFIG', -1): 'HKEY_CURRENT_CONFIG',
    }
    return mapping.get(root, str(root))


def _collect_services() -> List[Dict[str, Any]]:
    """Collect persistence items from Windows services using the `sc` command."""
    entries: List[Dict[str, Any]] = []
    now = _current_timestamp()
    try:
        # Query all services
        output = subprocess.check_output(["sc", "query", "state=", "all"], stderr=subprocess.STDOUT, text=True)
        lines = output.splitlines()
        current_service: Optional[str] = None
        for line in lines:
            line = line.strip()
            if line.startswith("SERVICE_NAME:"):
                current_service = line.split(":", 1)[1].strip()
            elif line.startswith("BINARY_PATH_NAME") and current_service:
                # sc query doesn't output BINARY_PATH_NAME here; we will query later in qc call.
                pass
            elif line == "" and current_service:
                # At the end of a service block; query details
                try:
                    qc_output = subprocess.check_output(["sc", "qc", current_service], stderr=subprocess.STDOUT, text=True)
                    exe_path = ""
                    for qc_line in qc_output.splitlines():
                        qc_line = qc_line.strip()
                        if qc_line.upper().startswith("BINARY_PATH_NAME"):
                            exe_path = qc_line.split(None, 1)[-1].strip().strip('"')
                            break
                    entries.append({
                        "id": hashlib.md5(current_service.encode("utf-8")).hexdigest(),
                        "name": current_service,
                        "location": current_service,
                        "type": "service",
                        "hash": _hash_file(exe_path) if exe_path else "",
                        "timestamp": now,
                    })
                except Exception:
                    entries.append({
                        "id": hashlib.md5(current_service.encode("utf-8")).hexdigest(),
                        "name": current_service,
                        "location": current_service,
                        "type": "service",
                        "hash": "",
                        "timestamp": now,
                    })
                current_service = None
    except Exception:
        # On failure, return empty list of services to avoid crashing
        return entries
    return entries


def _collect_scheduled_tasks() -> List[Dict[str, Any]]:
    """Collect persistence items from scheduled tasks using schtasks."""
    entries: List[Dict[str, Any]] = []
    now = _current_timestamp()
    try:
        # Query scheduled tasks in CSV format for easier parsing
        output = subprocess.check_output(["schtasks", "/Query", "/V", "/FO", "CSV"], stderr=subprocess.STDOUT, text=True)
        reader = csv.DictReader(output.splitlines())
        for row in reader:
            name = row.get('TaskName') or row.get('Task Name') or row.get('TaskName/JobName')
            # If name includes backslashes, remove leading backslash
            if name and name.startswith("\\"):
                name = name.lstrip("\\")
            location = row.get('TaskToRun') or row.get('Action') or ''
            # Extract executable path from TaskToRun by splitting at first space
            exe_path = ''
            if location:
                exe_path = location.strip('"').split(' ')[0]
            entries.append({
                "id": hashlib.md5((name or location).encode("utf-8")).hexdigest(),
                "name": name or location,
                "location": name or '',
                "type": "scheduled_task",
                "hash": _hash_file(exe_path) if exe_path and os.path.isfile(exe_path) else "",
                "timestamp": now,
            })
    except Exception:
        # On failure, return empty list of tasks to avoid crashing
        return entries
    return entries