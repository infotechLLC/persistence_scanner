"""Collect persistence items from the system.

This module contains a placeholder implementation of a persistence collector.  In a
production system you would inspect known persistence mechanisms such as services,
registry run keys, scheduled tasks, startup folder contents, WMI event filters,
etc.  For demonstration purposes this function returns a static list of items
annotated with a timestamp.  Each item is a dictionary with at least the
following keys:

* `id` – a unique identifier for the item (e.g. name/path hash).
* `name` – human‑friendly name.
* `location` – path or registry key where the persistence hook lives.
* `type` – type of persistence (service, task, startup, etc.).
* `hash` – optional cryptographic hash of the executable or script.
* `timestamp` – when the entry was collected.

Replace the body of `collect_persistence()` with a real collector to integrate
with your environment.
"""

from __future__ import annotations

import hashlib
import os
import platform
from datetime import datetime
from typing import List, Dict, Any


def _hash_file(path: str) -> str:
    """Compute a SHA256 hash of a file.  If the file cannot be read, returns an empty string."""
    try:
        with open(path, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()
    except (OSError, IOError):
        return ""


def collect_persistence() -> List[Dict[str, Any]]:
    """Collect persistence items from the system.

    If running on Windows, attempt to collect real persistence mechanisms
    using the helper functions in `windows_collector.py`.  Otherwise fall
    back to a stubbed implementation that treats files in the current
    working directory as persistence entries.  Each item returned has at
    least the keys described in the module docstring.
    """
    # Check if we're running on Windows and import the Windows collector if possible
    items: List[Dict[str, Any]]
    try:
        if platform.system().lower() == "windows":
            # Local import to avoid Windows-only dependencies on non-Windows
            from . import windows_collector  # type: ignore
            items = windows_collector.collect_windows_persistence()
        else:
            raise ImportError
    except Exception:
        # Use stubbed implementation when not on Windows or on error
        items = _collect_stub()
    return items


def _collect_stub() -> List[Dict[str, Any]]:
    """Return a fabricated list of persistence entries for non-Windows systems.

    This function scans the current working directory and treats each file
    as a persistence item.  It also adds an example scheduled task.  Used
    primarily for development and testing on non-Windows platforms.
    """
    items: List[Dict[str, Any]] = []
    now = datetime.utcnow().isoformat() + "Z"
    cwd = os.getcwd()
    for filename in os.listdir(cwd):
        full_path = os.path.join(cwd, filename)
        if os.path.isfile(full_path):
            items.append({
                "id": hashlib.md5(full_path.encode("utf-8")).hexdigest(),
                "name": filename,
                "location": full_path,
                "type": "file",
                "hash": _hash_file(full_path),
                "timestamp": now,
            })
    items.append({
        "id": "example-task",
        "name": "Daily Cleanup Task",
        "location": "Task Scheduler/\\Microsoft\\Windows\\CleanUp",
        "type": "scheduled_task",
        "hash": "",
        "timestamp": now,
    })
    return items