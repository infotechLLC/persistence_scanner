"""Persistence scanner package.

This package contains modules to collect persistence information, compare baselines,
and generate reports.  See `collector.py`, `comparator.py` and `report.py` for details.
"""

__all__ = ["collect_persistence", "diff_baseline", "generate_report"]

from .collector import collect_persistence
from .comparator import diff_baseline
from .report import generate_report