"""Generate HTML reports for persistence diffs.

This module uses Jinja2 to render a simple HTML file summarizing the
differences between a baseline and a current scan.  The `generate_report()`
function accepts a diff dictionary with `new`, `removed` and `modified`
entries and writes an HTML file based on a template stored in
`templates/report.html`.

To add new columns or styling, edit the template instead of the Python code.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Any, List

from jinja2 import Environment, FileSystemLoader, select_autoescape


def generate_report(diff: Dict[str, Any], out_file: Path) -> None:
    """Generate an HTML report from diff results.

    Args:
        diff: A dictionary containing `new`, `removed` and `modified` items.
        out_file: The path to the HTML file to write.
    """
    template_dir = Path(__file__).resolve().parent.parent / "templates"
    env = Environment(
        loader=FileSystemLoader(str(template_dir)),
        autoescape=select_autoescape(["html", "xml"]),
    )
    template = env.get_template("report.html")
    html = template.render(diff=diff)

    out_file.parent.mkdir(parents=True, exist_ok=True)
    with out_file.open("w", encoding="utf-8") as f:
        f.write(html)