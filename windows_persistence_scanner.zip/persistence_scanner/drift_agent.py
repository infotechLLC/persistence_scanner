"""Drift detection agent for Windows persistence entries.

This module implements a simple drift detection mechanism that monitors
changes to persistence points such as startup folders, Run registry keys,
services, and scheduled tasks.  It compares the current state of these
entries against a baseline and logs any additions, removals or
modifications.  The agent can run in a background loop performing
periodic scans, and on Windows can optionally use native event
notifications to react immediately to changes if the necessary
dependencies (`pywin32`, `watchdog`) are available.

At startup the agent loads or creates a baseline.  Each time a change
is detected, the baseline is updated to reflect the new state so that
subsequent changes are only reported once.

This code is designed as a reference implementation; it focuses on
simplicity and portability rather than maximum efficiency.  In
production you may want to implement registry and file system event
watchers for true real‑time detection.
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import platform
import threading
import time
from pathlib import Path
from typing import List, Dict, Any

from .collector import collect_persistence
from .comparator import diff_baseline


class DriftAgent:
    """Continuously monitor persistence changes and log drift events."""

    def __init__(self, baseline_path: Path, log_path: Path, interval: int = 60) -> None:
        self.baseline_path = baseline_path
        self.log_path = log_path
        self.interval = interval
        self._stop_event = threading.Event()
        self._baseline: List[Dict[str, Any]] = []
        self._load_or_init_baseline()
        self._setup_logger()

    def _setup_logger(self) -> None:
        logging.basicConfig(
            filename=str(self.log_path),
            level=logging.INFO,
            format="%(asctime)s %(levelname)s: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        self.logger = logging.getLogger("drift_agent")
        # Also log to console for immediate feedback
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        formatter = logging.Formatter("%(asctime)s %(levelname)s: %(message)s", "%Y-%m-%d %H:%M:%S")
        console_handler.setFormatter(formatter)
        self.logger.addHandler(console_handler)

    def _load_or_init_baseline(self) -> None:
        if self.baseline_path.exists():
            try:
                with self.baseline_path.open("r", encoding="utf-8") as f:
                    self._baseline = json.load(f)
            except Exception:
                # If baseline file is corrupt, rebuild baseline
                self._baseline = []
        if not self._baseline:
            self.logger = logging.getLogger("drift_agent")
            # Create baseline by scanning current state
            self.logger.info("Initializing baseline by scanning current persistence entries")
            self._baseline = collect_persistence()
            self._save_baseline()

    def _save_baseline(self) -> None:
        self.baseline_path.parent.mkdir(parents=True, exist_ok=True)
        with self.baseline_path.open("w", encoding="utf-8") as f:
            json.dump(self._baseline, f, indent=2, ensure_ascii=False)

    def _scan_once(self) -> None:
        current = collect_persistence()
        diff = diff_baseline(self._baseline, current)
        if diff["new"] or diff["removed"] or diff["modified"]:
            self._log_diff(diff)
            # Update baseline to the new current state so changes are not reported repeatedly
            self._baseline = current
            self._save_baseline()

    def _log_diff(self, diff: Dict[str, Any]) -> None:
        # Log each new, removed and modified item separately for clarity
        for item in diff["new"]:
            self.logger.info(f"New persistence item detected: {item['type']} '{item['name']}' at {item['location']}")
        for item in diff["removed"]:
            self.logger.info(f"Persistence item removed: {item['type']} '{item['name']}' from {item['location']}")
        for change in diff["modified"]:
            baseline_item = change["baseline"]
            current_item = change["current"]
            # Identify which fields changed
            for key in baseline_item:
                if key == "timestamp":
                    continue
                if baseline_item.get(key) != current_item.get(key):
                    self.logger.info(
                        f"Persistence item modified: id={baseline_item['id']} field={key} "
                        f"'{baseline_item.get(key)}' -> '{current_item.get(key)}'"
                    )

    def start(self) -> None:
        """Start the monitoring loop.  Runs until stop() is called."""
        self.logger.info(f"Starting drift agent. Monitoring interval: {self.interval} seconds")
        # Attempt to start advanced watchers on Windows if dependencies are present
        if platform.system().lower() == "windows":
            try:
                # Import optional modules for file system and registry watching
                import importlib
                # Try to load watchdog for file monitoring
                watchdog_spec = importlib.util.find_spec("watchdog")
                pywin32_spec = importlib.util.find_spec("win32api")
                if watchdog_spec and pywin32_spec:
                    self.logger.info("Advanced event watchers available. Starting event-driven drift detection.")
                    self._run_event_driven_watchers()
                    return
                else:
                    self.logger.info("Advanced event watchers not available. Falling back to periodic scanning.")
            except Exception:
                # If detection of dependencies fails, fallback to periodic scanning
                pass
        # Fallback to periodic scanning
        self._run_periodic()

    def _run_periodic(self) -> None:
        """Periodically scan for persistence drift."""
        while not self._stop_event.is_set():
            try:
                self._scan_once()
            except Exception as e:
                self.logger.error(f"Error during scan: {e}")
            # Wait for the next interval, but break early if stopped
            for _ in range(self.interval):
                if self._stop_event.is_set():
                    break
                time.sleep(1)
        self.logger.info("Drift agent stopped.")

    def _run_event_driven_watchers(self) -> None:
        """Run event-driven drift detection using watchdog and pywin32.

        This method will set up file system watchers for the startup directories
        and scheduled tasks, and registry watchers for Run keys and services.
        When an event occurs, it will compare the current state against the
        baseline and log any differences.  This requires both the `watchdog`
        and `pywin32` packages to be installed and only works on Windows.
        """
        # Lazy imports inside the method since they are only needed here
        import importlib
        import queue
        import threading
        from pathlib import Path
        # Imports from watchdog
        watchdog_events = importlib.import_module("watchdog.events")
        watchdog_observers = importlib.import_module("watchdog.observers")
        # Imports from pywin32
        win32api = importlib.import_module("win32api")
        win32con = importlib.import_module("win32con")

        event_queue: queue.Queue[str] = queue.Queue()

        # File system watcher handler for startup directories and tasks
        class FileChangeHandler(watchdog_events.FileSystemEventHandler):
            def on_created(self, event):
                event_queue.put("file_change")
            def on_deleted(self, event):
                event_queue.put("file_change")
            def on_modified(self, event):
                # Only handle modifications for directory watchers (e.g., schedule tasks changed)
                event_queue.put("file_change")

        observer = watchdog_observers.Observer()

        # Determine startup directories and tasks directory
        try:
            startup_dirs = []
            appdata = os.environ.get("APPDATA")
            if appdata:
                startup_dirs.append(Path(appdata) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup")
            programdata = os.environ.get("PROGRAMDATA")
            if programdata:
                startup_dirs.append(Path(programdata) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup")
            tasks_dir = Path(os.environ.get("SystemRoot", "C:\\Windows")) / "System32" / "Tasks"
            startup_dirs.append(tasks_dir)
            for path in startup_dirs:
                if path.exists():
                    observer.schedule(FileChangeHandler(), str(path), recursive=True)
        except Exception:
            # If startup directories cannot be determined, fallback to periodic scanning
            self.logger.warning("Could not determine startup directories. Falling back to periodic scanning.")
            self._run_periodic()
            return

        # Registry watcher function
        def registry_watch(key_handle, watch_subtree: bool, notify_filter: int):
            while not self._stop_event.is_set():
                try:
                    win32api.RegNotifyChangeKeyValue(key_handle, watch_subtree, notify_filter, None, False)
                    event_queue.put("registry_change")
                except Exception as e:
                    self.logger.error(f"Registry watch error: {e}")
                    break

        # Open registry keys to watch
        registry_threads: List[threading.Thread] = []
        try:
            # Open Run keys
            run_keys = [
                (win32con.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run"),
                (win32con.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\Run"),
            ]
            for root, subkey in run_keys:
                try:
                    key_handle = win32api.RegOpenKeyEx(root, subkey, 0, win32con.KEY_NOTIFY)
                    t = threading.Thread(
                        target=registry_watch,
                        args=(key_handle, False, win32con.REG_NOTIFY_CHANGE_NAME | win32con.REG_NOTIFY_CHANGE_LAST_SET),
                        daemon=True,
                    )
                    registry_threads.append(t)
                    t.start()
                except Exception as e:
                    self.logger.warning(f"Failed to watch registry key {root}:{subkey}: {e}")
            # Watch Services key for new/removed services
            try:
                services_handle = win32api.RegOpenKeyEx(win32con.HKEY_LOCAL_MACHINE, r"System\CurrentControlSet\Services", 0, win32con.KEY_NOTIFY)
                t = threading.Thread(
                    target=registry_watch,
                    args=(services_handle, True, win32con.REG_NOTIFY_CHANGE_NAME),
                    daemon=True,
                )
                registry_threads.append(t)
                t.start()
            except Exception as e:
                self.logger.warning(f"Failed to watch Services registry: {e}")
        except Exception:
            self.logger.error("Error setting up registry watchers")
            observer.stop()
            observer.join()
            self._run_periodic()
            return

        # Start file system observer
        observer.daemon = True
        observer.start()
        self.logger.info("Event-driven drift detection started")

        try:
            while not self._stop_event.is_set():
                try:
                    # Wait for an event with timeout to allow checking stop_event
                    event_queue.get(timeout=1)
                    # On any event, scan once
                    self._scan_once()
                except queue.Empty:
                    continue
        finally:
            observer.stop()
            observer.join()
            for t in registry_threads:
                # No explicit join here; threads will exit on their own when stop_event is set
                pass
            self.logger.info("Event-driven drift detection stopped")

    def stop(self) -> None:
        """Signal the agent to stop monitoring."""
        self._stop_event.set()


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the persistence drift detection agent")
    parser.add_argument("--baseline", type=Path, required=True, help="Path to the baseline JSON file")
    parser.add_argument("--log", type=Path, required=True, help="Path to the log file for changes")
    parser.add_argument("--interval", type=int, default=60, help="Scan interval in seconds when event-driven monitoring is not available")
    args = parser.parse_args()
    agent = DriftAgent(args.baseline, args.log, args.interval)
    try:
        agent.start()
    except KeyboardInterrupt:
        agent.logger.info("Keyboard interrupt received, stopping drift agent")
        agent.stop()


if __name__ == "__main__":
    main()