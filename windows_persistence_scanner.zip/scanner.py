"""Command line interface for the Windows persistence scanner.

This script exposes three subcommands:

1. `baseline` – Collects persistence items and writes them to a JSON file.
2. `scan` – Collects persistence items and writes them to a JSON file.
3. `diff` – Compares two JSON files (baseline and current) and generates an HTML report.

Usage examples:

```bash
python scanner.py baseline --out baseline.json
python scanner.py scan --out current.json
python scanner.py diff --baseline baseline.json --current current.json --out report.html
```
"""

import argparse
import json
from pathlib import Path
from typing import List, Dict, Any

from persistence_scanner.collector import collect_persistence
from persistence_scanner.comparator import diff_baseline
from persistence_scanner.report import generate_report
from persistence_scanner.drift_agent import DriftAgent


def write_json(filename: Path, data: List[Dict[str, Any]]) -> None:
    """Write a list of dictionaries to a JSON file with pretty formatting."""
    filename.parent.mkdir(parents=True, exist_ok=True)
    with filename.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def read_json(filename: Path) -> List[Dict[str, Any]]:
    """Read a JSON file and return a list of dictionaries."""
    with filename.open("r", encoding="utf-8") as f:
        return json.load(f)


def command_baseline(args: argparse.Namespace) -> None:
    """Handle the `baseline` subcommand."""
    items = collect_persistence()
    write_json(args.out, items)
    print(f"Baseline written to {args.out}")


def command_scan(args: argparse.Namespace) -> None:
    """Handle the `scan` subcommand."""
    items = collect_persistence()
    write_json(args.out, items)
    print(f"Current scan written to {args.out}")


def command_diff(args: argparse.Namespace) -> None:
    """Handle the `diff` subcommand."""
    baseline_items = read_json(args.baseline)
    current_items = read_json(args.current)
    diff = diff_baseline(baseline_items, current_items)
    generate_report(diff, args.out)
    print(f"Report written to {args.out}")


def command_watch(args: argparse.Namespace) -> None:
    """Handle the `watch` subcommand for real-time drift detection."""
    agent = DriftAgent(args.baseline, args.log, args.interval)
    try:
        agent.start()
    except KeyboardInterrupt:
        agent.logger.info("Keyboard interrupt received, stopping drift agent")
        agent.stop()


def build_argument_parser() -> argparse.ArgumentParser:
    """Build and return the argument parser for the CLI."""
    parser = argparse.ArgumentParser(description="Windows persistence baseline and diff scanner")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # Baseline command
    baseline_parser = subparsers.add_parser("baseline", help="Collect baseline persistence items")
    baseline_parser.add_argument("--out", type=Path, required=True, help="Output JSON file for the baseline")
    baseline_parser.set_defaults(func=command_baseline)

    # Scan command
    scan_parser = subparsers.add_parser("scan", help="Collect current persistence items")
    scan_parser.add_argument("--out", type=Path, required=True, help="Output JSON file for the current scan")
    scan_parser.set_defaults(func=command_scan)

    # Diff command
    diff_parser = subparsers.add_parser("diff", help="Compare baseline and current scan and generate a report")
    diff_parser.add_argument("--baseline", type=Path, required=True, help="Baseline JSON file")
    diff_parser.add_argument("--current", type=Path, required=True, help="Current scan JSON file")
    diff_parser.add_argument("--out", type=Path, required=True, help="Output HTML report file")
    diff_parser.set_defaults(func=command_diff)

    # Watch command
    watch_parser = subparsers.add_parser("watch", help="Monitor persistence drift in real-time or periodically")
    watch_parser.add_argument("--baseline", type=Path, required=True, help="Baseline JSON file for drift detection")
    watch_parser.add_argument("--log", type=Path, required=True, help="Log file to record drift events")
    watch_parser.add_argument(
        "--interval", type=int, default=60,
        help="Interval in seconds between scans when event-driven monitoring is unavailable (default: 60 seconds)"
    )
    watch_parser.set_defaults(func=command_watch)

    return parser


def main() -> None:
    parser = build_argument_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()