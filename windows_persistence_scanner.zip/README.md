# Windows Persistence Baseline & Drift Scanner

This repository contains a minimal proof‑of‑concept for a Windows persistence scanner.  The goal is to baseline a host’s persistence points (services, startup programs, scheduled tasks, etc.), detect changes over time, and generate an easy‑to‑read HTML report.

## Components

* `scanner.py` – Command line interface with three subcommands:
  * `baseline` – Collects a list of persistence items and saves them to a JSON baseline file.
  * `scan` – Collects current persistence items and saves them to a JSON file.
  * `diff` – Compares a baseline file and a current scan file to produce an HTML report highlighting new, removed, or modified items.

* `persistence_scanner/` – Library modules used by the CLI:
  * `collector.py` – Dispatches to platform‑specific collectors.  On Windows, it will use `windows_collector.py` to enumerate persistence mechanisms such as services, scheduled tasks, registry run keys and startup folders.  On other platforms it returns stub data.
  * `windows_collector.py` – Implements best‑effort enumeration of common Windows persistence mechanisms using the `winreg` module and command‑line utilities (`sc`, `schtasks`).  It returns a structured list of persistence items that includes a SHA256 hash of each executable if available.
  * `comparator.py` – Provides a `diff_baseline()` function that compares two lists of persistence entries and identifies new, removed and modified items.
  * `report.py` – Generates an HTML report from the diff results.  It uses the Jinja2 templating library and a simple template included in `templates/report.html`.

  * `drift_agent.py` – Implements a drift detection agent that continuously monitors persistence points.  It compares the current state against a baseline and logs any additions, removals or modifications.  On Windows it can leverage event notifications via `pywin32` and `watchdog`; otherwise it falls back to periodic scanning.

* `templates/` – Contains HTML templates used for report generation.

## Quick Start

1. **Install dependencies.**  The only external dependency for this demo is Jinja2.  Install it with pip:

   ```bash
   pip install Jinja2
   ```

2. **Run a baseline scan.**

   ```bash
   python scanner.py baseline --out baseline.json
   ```

3. **Run a follow‑up scan.**

   ```bash
   python scanner.py scan --out current.json
   ```

4. **Generate a diff report.**

   ```bash
   python scanner.py diff --baseline baseline.json --current current.json --out report.html
   ```

5. **Monitor for drift in real time.**

   After establishing a baseline, you can start the drift agent to continuously watch for changes:

   ```bash
   python scanner.py watch --baseline baseline.json --log drift.log --interval 30
   ```

   This command runs the drift detection agent which scans every 30 seconds (or uses event notifications on Windows if available).  Any new, removed or modified persistence entries will be logged to `drift.log`.

This will produce `report.html` which you can open in any browser to view a simple summary of changes.

## Notes

This is intentionally minimal and is meant as a starting point.  For real use you would replace the stubbed functions in `collector.py` with code that interrogates the Windows operating system APIs or uses WMI to gather persistence artifacts.  You would also likely expand the report formatting and logic to better suit your environment and risk scoring model.